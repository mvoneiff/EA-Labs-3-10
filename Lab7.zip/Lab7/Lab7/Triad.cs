﻿using System;
namespace Lab7
{
    public class Triad<T> where T : IComparable<T>
    {
        // Auto-implemented properties for the Triad class
        public T First { get; set; }
        public T Second { get; set; }
        public T Third { get; set; }

        // Constructor to initialize the properties
        public Triad(T first, T second, T third)
        {
            First = first;
            Second = second;
            Third = third;
        }

        // Method to find the largest value
        public T GetLargest()
        {
            T max = First;
            if (Second.CompareTo(max) > 0)
            {
                max = Second;
            }
            if (Third.CompareTo(max) > 0)
            {
                max = Third;
            }
            return max;
        }
    }
}

