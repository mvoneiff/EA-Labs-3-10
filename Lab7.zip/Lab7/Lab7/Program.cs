﻿using System;

namespace Lab7;

class Program
{
    static void Main()
    {
        // Create an instance of Triad with int type and test values
        Triad<int> triad = new Triad<int>(10, 20, 30);

        // Display the largest value
        Console.WriteLine($"The largest value is: {triad.GetLargest()}");
    }
    //Other types of constraints, Assisted by AI:
//where T : struct - T must be a non-nullable value type.
//where T : class - T must be a reference type.
//where T : new () - T must have a public parameterless constructor.
//where T : <base class name> - T must be or derive from the specified base class.
//where T : <interface name> - T must be or implement the specified interface.
//where T : unmanaged - T must be an unmanaged type.
//where T : notnull - T must be a non-nullable type1.
}

