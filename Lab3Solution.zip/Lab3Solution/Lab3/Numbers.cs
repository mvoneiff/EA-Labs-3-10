﻿using System;
using System.Collections.Generic;
namespace Lab3
{
	public class Numbers
	{
		//declare lists
		public List<int> X { get; set; }
		public List<int> Y { get; set; }
		public Numbers()
		{
			//initialize lists
			X = new List<int>
			{
				1,2,3,4,5,6,7,8,9,10
			};
			Y = new List<int>
			{
				5,6,7,8,9,10,11,12,13,14
			};
		}
		public List<int> Process(Func<int, int, int> doMath)
		{
			List<int> result = new List<int>();
			//Loop that iterates through X list
			for (int i = 0; i < X.Count; i++)
			{
				//check to see if X index is less than the Y index
				if (i < Y.Count)
				{
					result.Add(doMath(X[i], Y[i]));
				}
				else
				{
					result.Add(X[i]);
				}
			}

			// Add the rest of the Y values to list
			for(int i = X.Count; i < Y.Count; i++)
			{
				result.Add(Y[i]);
			}
			return result;
		}
		public List<int> Find(Predicate<int> predicate)
		{
			List<int> result = new List<int>();

			// Loop to iterate through
			foreach (int x in X)
			{
				if (predicate(x))
				{
					result.Add(x);
				}
			}

			foreach (int y in Y)
			{
				if (predicate(y))
				{
					result.Add(y);
				}
			}
			return result;
		}

	}
}

