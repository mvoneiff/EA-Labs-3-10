﻿namespace Lab3;

class Program
{
    static void Main(string[] args)
    {
        Numbers numbers = new Numbers();

        // call the method with lambda
        List<int> addResult = numbers.Process((x, y) => x + y);
        Console.WriteLine(string.Join(", ", addResult));

        List<int> subtractResult = numbers.Process((x, y) => x - y);
        Console.WriteLine(string.Join(", ", subtractResult));

        List<int> multiplyResult = numbers.Process((x, y) => x * y);
        Console.WriteLine(string.Join(", ", multiplyResult));

        List<int> divideResult = numbers.Process((x, y) => x / y);
        Console.WriteLine(string.Join(", ", divideResult));

        // Call the find method with lambda
        List<int> findResult = numbers.Find(x => x >= 8 && x <= 11);
        Console.WriteLine(string.Join(", ", findResult));
    }
}

