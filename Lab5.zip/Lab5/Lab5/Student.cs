﻿using System;
namespace Lab5
{
	public class Student
	{
		private string name;
		private double gpa;
		public string Name
		{
			get
			{
				return name;
			}
			set
			{
				if (string.IsNullOrEmpty(value))
				{
					throw new StudentException("Name cannot be null or empty.");
				}
				name = value;
			}
		}

		public double GPA
		{
			get
			{
				return gpa;
			}
			set
			{
				if(value < 0 || value > 4.0)
				{
					throw new StudentException("GPA must be between 0 and 4.0.");
				}
				gpa = value;
			}
		}
		public Student(string name, double gpa)
		{
				Name = name;
				GPA = gpa;
			
		}
		public void Display()
		{
			Console.WriteLine($"Name: {Name}\nGPA: {GPA}\n");
		}
	}
}

