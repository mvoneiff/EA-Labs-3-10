﻿using System;
namespace Lab5;

class Program
{
    static void Main(string[] args)
    {
        string name;
        double gpa;
        Student student;
        bool continueLoop = true; // Flag to control the loop

        while (continueLoop)
        {
            Console.Write("Enter the student's name: ");
            name = Console.ReadLine();
            Console.Write("Enter the student's GPA: ");
            if (!double.TryParse(Console.ReadLine(), out gpa))
            {
                Console.WriteLine("Invalid input. Please enter a number for GPA.");
                continue;
            }

            try
            {
                student = new Student(name, gpa);
                student.Display();
                continueLoop = false; // Set the flag to false to exit the loop
            }
            catch (StudentException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (ArgumentNullException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (ArgumentOutOfRangeException e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}



