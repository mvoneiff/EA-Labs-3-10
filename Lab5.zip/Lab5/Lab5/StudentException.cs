﻿using System;
namespace Lab5
{
	public class StudentException : Exception
	{
        public StudentException() : base("Invalid input, please try again.") { }
        public StudentException(string message) : base(message) { }
        public StudentException(string message, Exception inner) : base(message, inner) { }
    }
}

