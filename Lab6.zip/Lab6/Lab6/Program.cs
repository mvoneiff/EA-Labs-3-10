﻿namespace Lab6;
//Matt Von Eiff
class Program
{
    static void Main(string[] args)
    {
        // Create an instance of the Customer class called customer1
        Customer customer1 = new Customer(236, "Bob", 256.33);

        // Create a second instance of the Customer class called customer2
        Customer customer2 = new Customer(236, "Bob", 256.33);

        // Are the two instances you created above equal to each other? Should they be equal to each other?
        // Answer: No, the two instances are not equal to each other.
        // They should not be equal because they are two different objects.

        // Test your answer in code by using an if statement to compare customer1 with customer2
        if (customer1 == customer2)
        {
            Console.WriteLine("The two objects are equal.");
        }
        else
        {
            Console.WriteLine("The two objects are not equal.");
        }
        // Did you get the results you expected?
        // Answer: Yes, the two objects are not equal because they are two different objects in memory.

        customer2 = customer1;

        if (customer1 == customer2)
        {
            Console.WriteLine("The two objects are equal.");
        }
        else
        {
            Console.WriteLine("The two objects are not equal.");
        }
        // What result do you get?
        // Answer: Now the two objects are equal because they both point to the same object in memory.
    }
}
