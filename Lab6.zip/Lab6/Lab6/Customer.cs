﻿using System;
//Matt Von Eiff
namespace Lab6
{
    public class Customer
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public double Balance { get; set; }

        public Customer(int id, string name, double balance)
        {
            ID = id;
            Name = name;
            Balance = balance;
        }
        public override bool Equals(object obj)
        {
            return (obj as Customer)?.ID == ID;
        }
        // Try running your code again. Do they show up as equal yet?
        // Answer: no they are not equal yet
        public override int GetHashCode()
        {
            return ID.GetHashCode();
        }
        //Try running your code again. Do they show up as equal yet?
        // no they are not equal yet
        public static bool operator ==(Customer x, Customer y)
        {
            return x.Equals(y);
        }

        public static bool operator !=(Customer x, Customer y)
        {
            return !(x == y);
        }
        //Try running your code again.Do they show up as equal?
        // Yes they showed up as equals now
    }
}

