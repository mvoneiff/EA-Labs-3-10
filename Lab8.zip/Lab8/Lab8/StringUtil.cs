﻿using System;
namespace Lab8
{
	public static class StringUtil
	{
		public static string ReverseByCharacter(this string input)
		{
			char[] charArray = input.ToCharArray();
			Array.Reverse(charArray);
			return new string(charArray);
		}
		public static string ReverseByWord(this string input)
		{
            string[] words = input.Split(' ');
            Array.Reverse(words);
            return string.Join(" ", words);
        }
		public static bool PalindromeByCharacter(this string input)
		{
			string reversed = input.ReverseByCharacter();
			return input.Equals(reversed, StringComparison.OrdinalIgnoreCase);
		}
		public static bool PalindromeByWord(this string input)
		{
			string reversed = input.ReverseByWord();
			return input.Equals(reversed, StringComparison.OrdinalIgnoreCase);
		}
	}
}

