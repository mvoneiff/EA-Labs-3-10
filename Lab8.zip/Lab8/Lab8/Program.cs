﻿namespace Lab8;

class Program
{
    static void Main(string[] args)
    {
        string original = "hello there";
        string reversedByCharacter = original.ReverseByCharacter();
        string reversedByWord = original.ReverseByWord();
        bool isPalindromeByCharacter = original.PalindromeByCharacter();
        bool isPalindromeByWord = original.PalindromeByWord();

        Console.WriteLine($"Original: {original}");
        Console.WriteLine($"Reversed by Character: {reversedByCharacter}");
        Console.WriteLine($"Reversed by Word: {reversedByWord}");
        Console.WriteLine($"Is Palindrome by Character: {isPalindromeByCharacter}");
        Console.WriteLine($"Is Palindrome by Word: {isPalindromeByWord}");
    }
}