﻿using Lab4;

namespace Lab4Test;

[TestClass]
public class MathematicsTests
{
    [TestMethod]
    public void TestMethod1()
    {
        Mathematics mathematics = new Mathematics();
        double result = mathematics.Power(4, 2);
        Assert.AreEqual(16, result);
    }
    [TestMethod]
    public void TestMethod2()
    {
        Mathematics mathematics = new Mathematics();
        double result = mathematics.Power(0, 2);
        Assert.AreEqual(0, result);
    }
    [TestMethod]
    public void TestMethod3()
    {
        Mathematics mathematics = new Mathematics();
        double result = mathematics.Power(4, 0);
        Assert.AreEqual(1, result);
    }
    [TestMethod]
    public void TestMethod4()
    {
        Mathematics mathematics = new Mathematics();
        double result = mathematics.Power(2, -1);
        Assert.AreEqual(0.5, result);
    }
    [TestMethod]
    public void TestMethod5()
    {
        Mathematics mathematics = new Mathematics();
        double result = mathematics.Power(-2, 3);
        Assert.AreEqual(-8, result);
    }
    [TestMethod]
    public void TestMethod6()
    {
        Mathematics mathematics = new Mathematics();
        double result = mathematics.Power(-2, -1);
        Assert.AreEqual(-0.5, result);
    }
    [TestMethod]
    public void TestMethod7()
    {
        Mathematics mathematics = new Mathematics();
        Assert.ThrowsException<ArgumentException>(() => mathematics.Power(0, -1));
    }
    [TestMethod]
    public void TestMethod8()
    {
        Mathematics mathematics = new Mathematics();
        Assert.ThrowsException<ArgumentException>(() => mathematics.Perfect(0));
    }
    [TestMethod]
    public void TestMethod9()
    {
        Mathematics mathematics = new Mathematics();
        Assert.IsFalse(mathematics.Perfect(1));
    }
    [TestMethod]
    public void TestMethod10()
    {
        Mathematics mathematics = new Mathematics();
        Assert.IsTrue(mathematics.Perfect(6));
    }
}
