﻿namespace Lab4
{
	public class Mathematics
	{
		public double Power(int baseValue, int exponent)
		{
			int product = 1;
			for (int i =0; i < exponent; i++)
			{
				product *= baseValue;
			}
			if (exponent == 0)
			{
				product = 1;
			}
			if (exponent < 0)
			{
				if (baseValue == 0)
				{
					throw new ArgumentException("The base value cannot be 0 when the exponent is negative");
				}
				return 1 / (double)Power(baseValue, -exponent);
			}
			return product;
			
		}
		public bool Perfect(int value)
		{
			if (value <= 0)
			{
				throw new ArgumentException("The value must be a positive integer");
			}
			int sum = 0;
			for (int i = 1; i <= value / 2; i++)
			{
				if (value % i == 0)
				{
					sum += i;
				}
			}
			return sum == value;
        }
	}
}

